package co.edu.uptc.JavaProyect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacmanWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacmanWebApplication.class, args);
	}

}
