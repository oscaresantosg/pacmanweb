package co.edu.uptc.JavaProyect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacmanWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
